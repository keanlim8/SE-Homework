console.table(products)

class App extends React.Component {
  //old state
  // constructor() {
  //   super()
  //   this.state = {
  //     products: products
  //   }
  // }

  //new state
  state = {
    products: products
  }
  render() {
    return (
      <div>
        <h1>Big Time Shopping!</h1>
          // <ul>
          //   // {products.map(item => <li>{item.name}</li>)}
          // </ul>
      </div>
    )
  }
}

ReactDOM.render (
  <App />,
  document.querySelector('.container')
)
